
//modal창 생성
function createModal(msg){

    //const div = document.createElement('div');
    const container = document.createElement('div');
    const text = document.createElement('div');
    const button = document.createElement('button');
    const input = document.createElement('input');
    const input2 = document.createElement('input');
    const input3 = document.createElement('input');

    //div.setAttribute('id', 'modal');
   // div.style = 'position:absolute;width:100%;height:100%;';

    container.style = 'text-align:center;width:20rem;height:fit-content;background-color:lightgray;position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);border:1px solid black'
    container.id = 'modal';
    //text set
    text.style = 'display:block; padding:1rem 1rem';
    text.innerText = msg;
    //btn set
    button.type = 'button';
    button.id = 'confirm';
    button.style="margin:1rem";
    button.innerText = '확인';
    //input set
    input.type = 'text';
    input.style = ';margin:1rem;width:275px;display:block';
    input2.type = input.type;
    input2.style = ';margin:1rem;width:275px;display:block';
    input3.type = input.type;
    input3.style = ';margin:1rem;width:275px;display:block';
    
    container.appendChild(text);
     container.appendChild(input);
    container.appendChild(input2);
    container.appendChild(input3);
    container.appendChild(button);

    const button2 = document.createElement('button');
        button2.type = 'button';
        button2.id = 'cancel';
        button2.style="margin:1rem";
        button2.innerText = '취소';
    
    container.appendChild(button2);

    //div.appendChild(container);
    document.body.appendChild(container);
    
}






let result = {
    status: null,
    value: [],
};

function getTextValue(modal){

    var textInput = modal.querySelectorAll('input[type="text"]');

    if(!textInput) 
        return ;
    else
        return Array.from(textInput).map(e=>e.value);
}

//modal창 생성시 keyEvent
function keyDownEvent(selector){

    var confirmBtn = document.querySelector(selector.confirm);
    var cancelBtn = document.querySelector(selector.cancel);
    
    window.onkeydown = (e)=>{
        
        if(!confirmBtn){
            window.onkeydown = null; //keyEvent 종료
            return;
        }
        if(e.keyCode === 37 || e.keyCode === 9){
            confirmBtn.focus();
        }else if(e.keyCode === 39){
            cancelBtn.focus();
        }
    }
}

function promiseModal(selector){

    var modal = document.querySelector(selector.modal);

    //modal을 제외한 요소들을 비활성 하기위한 div적용
    var div = document.createElement('div');
    div.style = 'position:absolute;width:100%;height:100%;';
    div.appendChild(modal);
    document.body.prepend(div);

    keyDownEvent(selector);

    return new Promise((resolve, reject)=>{  
        document.querySelector(selector.confirm).addEventListener('click', ()=>{

            result.value = getTextValue(modal);
            result.status = true;
            resolve(result);
            document.querySelector(selector.modal).parentNode.remove(); //modal 종료

        });
        if(selector.cancel){
            document.querySelector(selector.cancel).addEventListener('click', ()=>{

                result.value = [];
                result.status = false;
                resolve(result);
                document.querySelector(selector.modal).parentNode.remove(); //modal 종료
                
            });
        }
    });
}








